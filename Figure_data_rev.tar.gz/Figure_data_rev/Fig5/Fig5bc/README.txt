(Data File)
File : MBGD_init-uni_dBS-0.010_depend-Q_data.txt

(File Format)
The 1st column	: the upper limit of Q used for MBGD calculation
The 2nd column	: Kai2
The 3rd column 	: MRE



