(Data File)
Data file for the upper limit of Q=0.04 : sph-iv_R10-120_bin-0.1_dBS-0.010_Q-0.040_hessian-ev_data.txt
Data file for the upper limit of Q=0.09 : sph-iv_R10-120_bin-0.1_dBS-0.010_Q-0.090_hessian-ev_data.txt
Data file for the upper limit of Q=0.26 : sph-iv_R10-120_bin-0.1_dBS-0.010_Q-0.260_hessian-ev_data.txt
Data file for the upper limit of Q=0.50 : sph-iv_R10-120_bin-0.1_dBS-0.010_Q-0.500_hessian-ev_data.txt


(File Format)
The 1st column	: eigenvalue number
The 2nd column 	: eigenvalue of hessian



