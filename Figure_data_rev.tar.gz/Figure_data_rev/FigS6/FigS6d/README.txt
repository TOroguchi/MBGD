(Data File)
Pseudo-true SAXS				   : 2bjb_more-open_rho-0.334_ws-0.00112_no-scale_ave-iv.txt
SAXS after MBGD initialized from uni.PD		   : 2bjb_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.04_out-20000000_iv.txt
SAXS after MBGD initialized from close-populated PD: 2bjb_more-close_fit-to_more-open_Q-0.50_dBS-0.010_step-0.04_out-20000000_iv.txt

(File Format for Pseudo-true SAXS)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS after reconstruction)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


