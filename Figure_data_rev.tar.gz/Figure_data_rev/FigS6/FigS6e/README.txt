(Data File)
Pseudo-true PD				: 2bjb_more-open_apdist_bin-0.1_wt.txt
MBGD initialized from uniform PD  	: 2bjb_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.04_out-20000000_wt.txt
MBGD initialized from close populated PD: 2bjb_more-close_fit-to_more-open_Q-0.50_dBS-0.010_step-0.04_out-20000000_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column  : PD value
