(PDB File)
Average structure from AAMD trajectory : 1bp5_FB15_TOH-120_293K-1_800ns_b-D1_c-D2_PCA_ave-all-pos.pdb
PC mode1 from AAMD trajectory	       : 1bp5_FB15_TOH-120_293K-1_800ns_b-D1_c-D2_PCA_mode00001_sigma-3.0.pdb
PC mode2 from AAMD trajectory	       : 1bp5_FB15_TOH-120_293K-1_800ns_b-D1_c-D2_PCA_mode00002_sigma-3.0.pdb

