(Data File)
Pseudo-true SAXS				   : 1ex6_more-open_rho-0.334_ws-0.00112_no-scale_ave-iv.txt
SAXS after MBGD initialized from uni.PD		   : 1ex6_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_iv.txt
SAXS after MBGD initialized from close-populated PD: 1ex6_more-close_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_iv.txt

(File Format for Pseudo-true SAXS)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS after reconstruction)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


