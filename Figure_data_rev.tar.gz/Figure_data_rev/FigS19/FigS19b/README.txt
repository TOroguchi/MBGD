(Experimental SAXS data)
File 	      	: SASDEL6_sigma-estimated-from-gnom-Dmax97_Q-0.20.dat 
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: sigma_I(Q)

(SAXS data for the initial PD)
File  	        : SjGlcNK_AAMD_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_step-0.0167_out-00000000_iv.txt
The 1st column 	: Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : z(Q)

(SAXS data after MBGD)
File            : SjGlcNK_AAMD_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_step-0.0167_out-00000700_iv.txt
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : z(Q)



