(Data file for PD)
PD after MBGD  	: SjGlcNK_AAMD_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_step-0.0167_out-00000700_wt_bin3-36.txt

(File Format)
The 2nd column  : PC1
The 3rd column	: PD value


