(Data File)
MBGD log: 6hwj-merge1_AAMD_wMG2+_FIT-TO_SASDEL6_Q-0.20_delta-0.0167_opt.log

(File Format for Logfile)
The 1st column	: step count
The 2nd column	: kai2
The 3rd column  : Forward KL-divergence (= alpha^k)
The 4th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 5th column  : Backward KL-divergence
The 6th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



