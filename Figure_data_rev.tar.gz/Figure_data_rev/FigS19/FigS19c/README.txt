(Data file for PD)
PD after MBGD  	: SjGlcNK_AAMD_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_step-0.0167_out-00000700_wt.txt

(File Format)
The 4th column	: PC1
The 5th column  : PC2
The 6th column	: PD value


