(Log file)
Logfile for MBGD with step size = 0.02 : 2bjb_more-close_fit-to_more-open_dBS-0.010_delta-0.02_opt_init-100.log
Logfile for MBGD with step size = 0.05 : 2bjb_more-close_fit-to_more-open_dBS-0.010_delta-0.05_opt_init-100.log

(File format for log file)
The 1st column	: Step count
The 2nd column	: Kai2
The 3rd column 	: MRE
The 4th column  : Forward KL-divergence
The 5th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 6th column  : Backward KL-divergence
The 7th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



