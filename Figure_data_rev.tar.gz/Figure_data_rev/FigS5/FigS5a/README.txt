(File)
2bjb_merge_pca-open-only_pc1-pc2_state00893_rho-0.334_ws-0.00112_noise-a0.001-b0.3_kai2-map.txt

(Format)
The 1st column: state number
The 2nd column: pc1
The 3rd column: pc2
The 4th column: kai2 of I(Q) beween the 893 th state and each state
