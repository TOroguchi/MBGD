(Data File)
SAXS from the 893th state with noise : 2bjb_merge_pca-open-only_pc1-pc2_state00893_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 302th state with Z(Q)   : 2bjb_merge_pca-open-only_pc1-pc2_state00302-vs-00893_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 801th state with Z(Q)  : 2bjb_merge_pca-open-only_pc1-pc2_state00801-vs-00893_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt

(File Format for SAXS data of the 893th state)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS data of the other states)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


