(PDB File)
Average structure from CGMD trajectory : 2bjb_open-only_run1-20_b-D1_c-D2_PCA_ave-all-pos.pdb 
PC mode1 from CGMD trajectory	       : 2bjb_open-only_run1-20_b-D1_c-D2_PCA_mode001_sigma-3.0.pdb
PC mode2 from CGMD trajectory	       : 2bjb_open-only_run1-20_b-D1_c-D2_PCA_mode002_sigma-3.0.pdb

