(Data File)
File :transferrin_more-close_fit-to_more-open_dBS-0.010_depend-delta_data1.txt

(File Format)
The 1st column	: step size
The 2nd column  : kai2
The 3rd column  : MRE
The 4th column  : abs((forward KLD - backward KLD)/forward KD)
These data were averaged over the first 1,000 steps.

