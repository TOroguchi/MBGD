(Data File)
Logfile for MBGD with timestep = 0.005: transferrin_more-close_fit-to_more-open_dBS-0.010_delta-0.005_opt_ts-1000.log

(File Format for Logfile)
The 1st column	: step count
The 2nd column	: kai2
The 3rd column 	: MRE
The 4th column  : Forward KL-divergence
The 5th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 6th column  : Backward KL-divergence
The 7th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



