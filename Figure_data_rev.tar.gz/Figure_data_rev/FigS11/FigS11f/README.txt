(Data File)
KL-divergence data for MBGD with step size = 0.005: transferrin_more-close_fit-to_more-open_dBS-0.010_Q-0.50_delta-0.005_kld_init-100.txt
KL-divergence data for MBGD with step size = 0.02: transferrin_more-close_fit-to_more-open_dBS-0.010_Q-0.50_delta-0.02_kld_init-100.txt

(File format)
The 1st column	: Step count
The 2nd column  : Forward KL-divergence
The 3rd column  : Backward KL-divergence
The 4th column  : Equivalence between the forward and backward KL divergences


