(Data File)
Pseudo-true SAXS: gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_ave-iv_dBS-0.010.txt
SAXS for uni.PSD: uni_bin-0.1_ave-iv_dBS-0.10.txt
SAXS for peak1	: state00401_iv.txt
SAXS for peak2	: state00701_iv.txt

(File Format)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: sigma of I(Q)

