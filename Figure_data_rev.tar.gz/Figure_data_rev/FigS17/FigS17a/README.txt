(Data File)
Pseudo-true PD         : transferrin_more-close_ddist2_bin-0.2_wt.txt
Initial PD             : transferrin_close-only_ddist2_bin-0.2_wt.txt
PD at 20th step of MBGD: transferrin_close-only_fit-to_more-open_a-0.003_delta-0.002_out-00003400_wt.txt

(File Format)
The 3rd column  : Domain distance
The 5th column  : PD value
