(Data file)
Logfile for KL-divergence : MBGD_init-uni_Q-0.50_dBS-0.010_delta-0.01_opt_init-1000_ts-1000_KLD.log

(File format)
The 1st column	: step count
The 2nd column  : Forward KL-divergence
The 3rd column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 4th column  : Backward KL-divergence
The 5th column  : abs(backward KL-divergence) (for small values < 1.0e-15)
The 6th column  : KL-divergence calculated from Eq. (7)


