(File)
Data file for Fig.S11c : SjGlcNK_merge_pca-open-only_pc1-pc2_ddist2.txt
Data file for Fig.S11d : SjGlcNK_merge_pca-open-only_pc1-pc2_apdist.txt

(Format)
The 1st column: state number
The 2nd column: pc1
The 3rd column: pc2
The 4th column: domain distance
