(Data File)
Data file : SjGlcNK_merge_pc1-pc2_bin-0.1_bclim-10_Q-0.20_hessian-ev_data.txt

(File Format)
The 1st column	: eigenvalue number
The 2nd column 	: eigenvalue of hessian



