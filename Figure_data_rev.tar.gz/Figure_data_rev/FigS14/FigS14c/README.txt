(Data File)
Hessian eigenvalues calculated from SAXS data     : 1ex6_merge_pc1-pc2_bin-2.0_bclim-10_SAXS-Q-0.50_hessian-ev_data.txt
Hessian eigenvalues calculated from DEER data     : 1ex6_merge_pc1-pc2_bin-2.0_bclim-10_DEER_hessian-ev_data.txt
Hessian eigenvalues calculated from SAXS+DEER data: 1ex6_merge_pc1-pc2_bin-2.0_bclim-10_SAXS-Q-0.50_DEER_hessian-ev_data.txt

(File Format)
The 1st column	: eigenvalue number
The 2nd column 	: eigenvalue of hessian



