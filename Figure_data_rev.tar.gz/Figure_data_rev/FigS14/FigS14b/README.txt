(Data File)
DEER signal calculated from pseudo-true ensemble      : 1ex6_more-open_deer_pair39-145_d-0.3_e-4.6_no-noise_sigma-0.02.txt
DEER signal calculated from force-field-based ensemble: 1ex6_more-close_deer_pair39-145_d-0.3_e-4.6_no-noise_sigma-0.02.txt
DEER signal calculated from uniform ensemble          : 1ex6_uni_deer_pair39-145_d-0.3_e-4.6_no-noise_sigma-0.02.txt

(File Format for Logfile)
The 1st column	: time /s
The 2nd column	: DEER signal
The 3rd column  : pseudo-experimental error



