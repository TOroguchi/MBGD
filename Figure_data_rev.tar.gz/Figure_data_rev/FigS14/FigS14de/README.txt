(Data file)
Kai2 map for only DEER data    : 1ex6_merge_pca-open-only_pc1-pc2_state04427_deer-pair39-145_kai2-map.txt
Kai2 map for SAXS and DEER data: 1ex6_merge_pca-open-only_pc1-pc2_state04427_SAXS_deer-pair39-145_kai2-map.txt

(Format)
The 1st column: state number
The 2nd column: pc1
The 3rd column: pc2
The 4th column: kai2 beween the 4427 th state and each state
