(Data File)
DEER signal after MBGD initialized from uni.PD            :1ex6_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_deer.txt
DEER signal after MBGD initialized from close-populated PD:1ex6_more-close_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_deer.txt

(File Format for Logfile)
The 1st column	: time /s
The 2nd column	: DEER signal



