(Data file)
PD after MBGD (slice): SjGlcNK_wCT_cryst+open1+snap-gr20_wMG2+_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_delta-0.0167_out-00001400_wt_bin3-34.txt

(File Format)
The 2nd column	: PC1
The 3rd column	: PD value


