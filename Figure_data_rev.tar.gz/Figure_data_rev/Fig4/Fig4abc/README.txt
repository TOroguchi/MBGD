(Data file)
Logfile for MBGD: MBGD_init-uni_Q-0.50_dBS-0.010_delta-0.01_opt_init-1000_ts-1000_extract.log
Logfile for GD	: GD_init-uni_Q-0.50_dBS-0.010_delta-0.0000005_opt_init-1000_ts-1000_extract.log
Logfile for LGD	: LGD_init-uni_Q-0.50_dBS-0.010_delta-1.0_opt_init-1000_ts-1000_extract.log

(File format for data file)
The 1st column	: Step count
The 2nd column	: Kai2
The 3rd column 	: MRE
The 4th column  : Forward KL-divergence
The 5th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 6th column  : Backward KL-divergence
The 7th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



