(Data File)
Pseudo-true SAXS: gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_ave-iv_dBS-0.010.txt
SAXS after MBGD : MBGD_init-uni_Q-0.50_dBS-0.010_delta-0.01_step-20000000_ave-iv.txt
SAXS after GD	: GD_init-uni_Q-0.50_dBS-0.010_delta-0.0000005_step-20000000_ave-iv.txt
SAXS after LGD	: LGD_init-uni_Q-0.50_dBS-0.010_delta-1.0_step-07000000_ave-iv.txt

(File Format for SAXS after reconstruction)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


