(Data File)
SAXS from the 1163th state with noise : transferrin_merge_pca-open-only_pc1-pc2_state01163_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 368th state with Z(Q)   : transferrin_merge_pca-open-only_pc1-pc2_state00368-vs-01163_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 1275th state with Z(Q)  : transferrin_merge_pca-open-only_pc1-pc2_state01275-vs-01163_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt

(File Format for SAXS data of the 1163th state)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS data of the other states)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


