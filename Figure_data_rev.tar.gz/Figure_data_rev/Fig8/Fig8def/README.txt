(Data file for PD)
AAMD PD		   : 6hwj-merge1_TOH-140_293K-1_run1-50_CGMD_pca-hopen-only_b-ID_c-CD3_Mode1-2_bclim-0_hist.txt
initial PD for MBGD: SjGlcNK_wCT_cryst+open1+snap-gr20_wMG2+.txt
PD after MBGD  	   : SjGlcNK_wCT_cryst+open1+snap-gr20_wMG2+_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_delta-0.0167_out-00001400_wt.txt

(File Format)
The 4th column	: PC1
The 5th column  : PC2
The 6th column	: PD value


(Data file for PC projection of structures)
Cryst. struct. 	       : cryst-struct_pca-proj.txt
Input struct. for CGMD : input-struct_for-CGMD.txt

(File format)
The 2nd column  : PC1
The 3rd column  : PC2

