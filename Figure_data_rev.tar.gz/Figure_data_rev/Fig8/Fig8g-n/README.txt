(PDB file)
Cryst. str. for holo	   :close-v3_wsub_VS_6hwj-mB_b-ID.pdb
Cryst. str. for apo	   :open-v3_wsub_VS_6hwj-mB_b-ID.pdb
Str. for dropped-jar conf1 :local_pc1-p110_pc2-m3_wsub_VS_6hwj-mB_b-ID.pdb
Str. for dropped-jar conf2 :local_pc1-p147_pc2-m41_wsub_VS_6hwj-mB_b-ID.pdb


