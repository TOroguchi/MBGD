(Data File)
MBGD log: SjGlcNK_cryst-only_FIT-TO_SASDEL6_pc1-pc2_Q-0.20_delta-0.0167_opt.log

(File Format for Logfile)
The 1st column	: step count
The 2nd column	: kai2
The 3rd column  : Forward KL-divergence (= alpha^k)
The 4th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 5th column  : Backward KL-divergence
The 6th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



