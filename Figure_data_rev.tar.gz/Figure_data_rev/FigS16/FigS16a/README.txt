(Data File)
Pseudo-true PD            : transferrin_more-open_ddist2_bin-0.2_wt.txt
Initial PD                : transferrin_more-close_ddist2_bin-0.2_wt.txt
PD at 20th step of MBGD   : transferrin_more-close_fit-to_more-open_a-0.003_delta-0.0167_out-00000020_wt.txt
PD at 1,930th stpe of MBGD: transferrin_more-close_fit-to_more-open_a-0.003_delta-0.0167_out-00001930_wt.txt

(File Format)
The 3rd column  : Domain distance
The 5th column  : PD value
