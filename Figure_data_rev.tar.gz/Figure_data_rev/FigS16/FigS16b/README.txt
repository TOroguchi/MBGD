(Data File)
Pseudo-experimental SAXS    : transferrin_more-open_rho-0.334_ws-0.00112_scale-1.0d4_offset-m0.2d5_a-0.003_b-0.3.txt
SAXS at 20th step of MBGD   : transferrin_more-close_fit-to_more-open_a-0.003_delta-0.0167_out-00000020_iv.txt
SAXS at 1,930th stpe of MBGD: transferrin_more-close_fit-to_more-open_a-0.003_delta-0.0167_out-00001930_iv.txt

(File Format for pseudo-experimental SAXS data)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS from initial models)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


