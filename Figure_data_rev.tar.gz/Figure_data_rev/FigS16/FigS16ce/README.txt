(Data File)
MBGD initialized from close-populated PD: transferrin_more-close_fit-to_more-open_a-0.003_delta-0.0167_opt.log

(File Format for Logfile)
The 1st column	: step count
The 2nd column	: kai2
The 3rd column 	: MRE
The 4th column  : Forward KL-divergence (= alpha^k in Fig. S16(e))
The 5th column  : abs(forward KL-divergence) (for small values < 1.0e-15)
The 6th column  : Backward KL-divergence
The 7th column  : abs(backward KL-divergence) (for small values < 1.0e-15)



