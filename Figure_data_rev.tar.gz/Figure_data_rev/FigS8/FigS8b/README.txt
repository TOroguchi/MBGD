(Data File)
Uniform PD as initial		               : 1ex6_uni_pc1-pc2_bin-2.0_wt.txt
PD obtained by MBGD initialized from uniform PD: 1ex6_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_wt.txt

(File Format)
The 1st column  : The state number on pc1
The 2nd column  : The state number on pc2
The 3rd column  : The value of pc1
The 4th column  : The value of pc2
The 5th column  : PD value


