(Data File)
Pseudo-true PD  : 1ex6_more-open_pc1-pc2_bin-2.0_wt.txt

(File Format)
The 1st column  : The state number on pc1
The 2nd column  : The state number on pc2
The 3rd column  : The value of pc1
The 4th column  : The value of pc2
The 5th column  : PD value


