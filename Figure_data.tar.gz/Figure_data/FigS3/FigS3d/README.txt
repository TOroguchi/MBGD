(File)
transferrin_merge_ddist2_bin-0.2_state-vs-state_rho-0.334_ws-0.00112_a-0.001_b-0.3_kai2-map.txt

(Format)
The 1st column: the i th state number
The 2nd column: the j th state number
The 3rd column: domain distance for the i th state number
The 4th column: domain distance for the j th state number
The 5th column: kai2 of SAXS data between the i and j th states
The 6th column: log10(kai2)
