(Data File)
SAXS from the 1591th state with noise : SjGlcNK_merge_pca-open-only_pc1-pc2_state01591_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 957th state with Z(Q)   : SjGlcNK_merge_pca-open-only_pc1-pc2_state0957-vs-01591_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 1744th state with Z(Q)  : SjGlcNK_merge_pca-open-only_pc1-pc2_state01744-vs-01591_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt

(File Format for SAXS data of the 1591th state)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS data of the other states)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


