(Data File)
open populated PD  : 2bjb_more-open_apdist_bin-0.2_wt.txt
close populated PD : 2bjb_more-close_apdist_bin-0.2_wt.txt
uniform PD	   : 2bjb_uni_apdist_bin-0.2_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column	: PD value
