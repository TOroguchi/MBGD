(File)
1ex6_merge3_pca-open-only_b-D1_c-D2_bin-1.0_bclim-10_cbin04427_rho-0.334_ws-0.00112_no-scale_a-0.001_b-0.3_kai2-map.txt

(Format)
The 1st column: state number
The 2nd column: pc1
The 3rd column: pc2
The 4th column: kai2 of I(Q) beween the 4427 th state and each state
