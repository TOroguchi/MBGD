(Data File)
SAXS from the 4427 th state with noise : 1ex6_merge_pca-open-only_pc1-pc2_state04427_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 2131 th state with Z(Q)  : 1ex6_merge_pca-open-only_pc1-pc2_state02131-vs-04427_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt
SAXS from the 3451 th state with Z(Q)  : 1ex6_merge_pca-open-only_pc1-pc2_state03451-vs-04427_rho-0.334_ws-0.00112_noise-a0.001-b0.3_iv.txt

(File Format for SAXS data of the 4427th state)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS data of the other states)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


