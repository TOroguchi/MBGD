(File)
Data file for Fig.S9c : 1ex6_merge_pca-open-only_pc1-pc2_ddist.txt
Data file for Fig.S9d : 1ex6_merge_pca-open-only_pc1-pc2_apdist.txt

(Format)
The 1st column: state number
The 2nd column: pc1
The 3rd column: pc2
The 4th column: domain distance
