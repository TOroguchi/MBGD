(PDB File)
Average structure from CGMD trajectory : 1ex6_open-only_run1-4_b-D1_c-D2_PCA_ave-all-pos.pdb
PC mode1 from CGMD trajectory	       : 1ex6_open-only_run1-4_b-D1_c-D2_PCA_mode001_sigma-5.0.pdb
PC mode2 from CGMD trajectory	       : 1ex6_open-only_run1-4_b-D1_c-D2_PCA_mode002_sigma-5.0.pdb

