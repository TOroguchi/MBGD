(Data file)
PCA results from AAMD		    :
PCA results from CGMD		    :
PC correlation between AAMD and CGMD:

(Format for PCA results)
The 1st column: PC number
The 2nd column: eigenvalue
The 3rd column: occupancy for total fluctuation
The 4th column: accumulation of eigenvalue
The 5th column: accumulation of occupancy

(Format for PC correlation)
The 1st column: PC number
The 2nd column: correlation
The 3rd column: abs(correlation)
