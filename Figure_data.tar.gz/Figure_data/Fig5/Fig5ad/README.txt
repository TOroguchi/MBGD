(Data File for Fig.5a)
MBGD initialized from uniform PSD	: MBGD_init-uni_Q-0.50_dBS-0.010_delta-0.01_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model1: MBGD_init-gmm1_Q-0.50_dBS-0.010_delta-0.01_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model2: MBGD_init-gmm2_Q-0.50_dBS-0.010_delta-0.01_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model3: MBGD_init-gmm3_Q-0.50_dBS-0.010_delta-0.01_wt_init-5000_ts-1000_plot.log
Landscape data	      	     	  	: sph-iv_gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_wt1-0.0010-0.0066_wt2-0.0015-0.0038_ibin_Q-0.50_dBS-0.01_kai2-arep-map_2D.txt

(Data File for Fig.5d)
MBGD initialized from uniform PSD       : MBGD_init-uni_Q-0.09_dBS-0.010_delta-0.005_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model1: MBGD_init-gmm1_Q-0.09_dBS-0.010_delta-0.005_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model2: MBGD_init-gmm2_Q-0.09_dBS-0.010_delta-0.005_wt_init-5000_ts-1000_plot.log
MBGD initialized from Gauss. mix. model3: MBGD_init-gmm3_Q-0.09_dBS-0.010_delta-0.005_wt_init-5000_ts-1000_plot.log
Landscape data                          : sph-iv_gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_wt1-0.0010-0.0066_wt2-0.0015-0.0038_ibin_Q-0.50_dBS-0.01_kai2-arep-map_2D.txt

(File Format for Logfile)
The 1st column	: step count
The 2nd column	: the position of peak1
The 3rd column 	: the probability value at peak1
The 4th column  : the position of peak2
The 5th column  : the probability value at peak2

(File Format for landscape data)
The 1st column	: the probability value at peak1
The 2nd column 	: the probability value at peak2
The 3rd column	: kai2
The 4th column  : MRE

