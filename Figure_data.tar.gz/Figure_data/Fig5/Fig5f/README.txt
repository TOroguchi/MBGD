(Data File)
File : sph-iv_R10-120_bin-0.1_dBS-0.010_nonzero-hessian-ev.txt

(File Format)
The 1st column	: the upper limit of Q used for hessian calculation
The 2nd column	: the number of nonzero eigenvalue of hessian



