(Data File)
Data file : 2bjb_merge_apdist_bin-0.1_bclim-10_Q-0.50_hessian-ev_data.txt

(File Format)
The 1st column	: eigenvalue number
The 2nd column 	: eigenvalue of hessian



