(Data File)
Pseudo-true PSD	: gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_wt.txt
PSD after MBGD	: MBGD_init-uni_Q-0.50_dBS-0.010_delta-0.01_out-20000000_wt.txt
PSD after GD    : GD_init-uni_Q-0.50_dBS-0.010_delta-0.0000005_out-20000000_wt.txt
PSD after LGD   : LGD_init-uni_Q-0.50_dBS-0.010_delta-1.0_out-07000000_wt.txt

(File Format)
The 2nd column	: Particle size /Angstrome
The 3rd column	: PSD value
