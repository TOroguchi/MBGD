(Data File)
Pseudo-true SAXS	: transferrin_more-open_rho-0.334_ws-0.00112_no-scale_ave-iv.txt
SAXS for uni.PD 	: transferrin_uni_fit-to_more-open_step-0.01_out-00000000_iv.txt
SAXS for close-populated: transferrin_more-close_fit-to_more-open_step-0.01_out-00000000_iv.txt

(File Format for pseudo-true SAXS data)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS from initial models)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


