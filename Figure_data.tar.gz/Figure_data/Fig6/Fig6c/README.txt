(Data File)
open populated PD  : transferrin_more-open_ddist2_bin-0.2_wt.txt
close populated PD : transferrin_more-close_ddist2_bin-0.2_wt.txt
uniform PD	   : transferrin_uni_ddist2_bin-0.2_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column	: PD value
