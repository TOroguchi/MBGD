(PDB File)
Average structure from AAMD trajectory : SjGlcNK_apo-open_run1_b-ID_c-CD4_PCA_ave-all-pos.pdb
PC mode1 from AAMD trajectory	       : SjGlcNK_apo-open_run1_b-ID_c-CD4_PCA_mode001_sigma-5.0.pdb
PC mode2 from AAMD trajectory	       : SjGlcNK_apo-open_run1_b-ID_c-CD4_PCA_mode002_sigma-5.0.pdb



