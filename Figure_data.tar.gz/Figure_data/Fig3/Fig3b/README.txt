(Data File)
Pseudo-true PSD	: gmm_g1-50.0-4.0_g2-80.0-10.0_r0.4_10-120_bin-0.1_wt.txt
uniform PSD 	: uni_10-120_bin-0.1_wt.txt

(File Format)
The 2nd column	: Particle size /Angstrome
The 3rd column	: PSD value
