(Data File)
Pseudo-true PD				: transferrin_more-open_ddist2_bin-0.2_wt.txt
MBGD initialized from uniform PD  	: transferrin_uni_fit-to_more-open_step-0.01_out-10000000_wt.txt
MBGD initialized from close populated PD: transferrin_more-close_fit-to_more-open_step-0.01_out-10000000_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column  : PD value
