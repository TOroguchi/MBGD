(Data File)
Pseudo-true SAXS				   : transferrin_more-open_rho-0.334_ws-0.00112_no-scale_ave-iv.txt
SAXS after MBGD initialized from uni.PD		   : transferrin_uni_fit-to_more-open_step-0.01_out-10000000_iv.txt
SAXS after MBGD initialized from close-populated PD: transferrin_more-close_fit-to_more-open_step-0.01_out-10000000_iv.txt

(File Format for Pseudo-true SAXS)
The 1st column  : Q /Angstrome^-1
The 2nd column  : I(Q)
The 3rd column  : sigma of I(Q)

(File Format for SAXS after reconstruction)
The 1st column	: Q /Angstrome^-1
The 2nd column	: I(Q)
The 3rd column 	: Z(Q)


