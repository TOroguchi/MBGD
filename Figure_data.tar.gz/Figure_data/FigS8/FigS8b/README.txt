(Data File)
Initial uniform PD		: 1ex6_uni_pc1-pc2_bin-2.0_wt.txt
MBGD initialized from uniform PD: 1ex6_uni_fit-to_more-open_Q-0.50_dBS-0.010_step-0.0125_out-05000000_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column  : PD value
