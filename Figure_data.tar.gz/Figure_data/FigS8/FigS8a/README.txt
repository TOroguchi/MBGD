(Data File)
open populated PD  : 1ex6_more-open_pc1-pc2_bin-2.0_wt.txt

(File Format)
The 3rd column	: Domain distance
The 5th column	: PD value
