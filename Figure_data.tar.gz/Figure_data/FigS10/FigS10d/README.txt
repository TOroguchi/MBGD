(Dependency data for the upper limit of Q: MBGD)
MBGD initialized from uniform PD        : 1ex6_uni_fit-to_more-open_dBS-0.010_step-0.0125_Q-depend.txt
MBGD initialized from close-populated PD: 1ex6_more-close_fit-to_more-open_dBS-0.010_step-0.0125_Q-depend.txt

(File Format: MBGD)
The 1st column	: the upper limit of Q used for MBGD calculation
The 2nd column  : Q*Rg
The 3rd column	: Kai2
The 4th column 	: MRE


(File for the number of nonzero eigenvalue of hessian)
1ex6_pc1-pc2_bin-2.0_nonzero-hessian-ev.txt

(File Format)
The 1st column  : the upper limit of Q used for hessian calculation
The 2nd column  : Q*Rg
The 3rd column  : the number of nonzero eigenvalue of hessian




